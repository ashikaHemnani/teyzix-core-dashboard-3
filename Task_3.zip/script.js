(() => {
  'use strict';

  /* ---------- Theme toggle ---------- */
  const root = document.documentElement;
  const themeToggle = document.getElementById('themeToggle');
  const savedTheme = (() => {
    try { return window.__ff_theme || null; } catch (e) { return null; }
  })();
  let currentTheme = savedTheme || 'dark';
  const applyTheme = (t) => {
    currentTheme = t;
    if (t === 'light') root.setAttribute('data-theme', 'light');
    else root.removeAttribute('data-theme');
    themeToggle.setAttribute('aria-pressed', String(t === 'light'));
    try { window.__ff_theme = t; } catch (e) {}
  };
  applyTheme(currentTheme);
  themeToggle.addEventListener('click', () => applyTheme(currentTheme === 'light' ? 'dark' : 'light'));

  /* ---------- Mobile nav ---------- */
  const burger = document.getElementById('navBurger');
  const navLinks = document.getElementById('navLinks');
  burger.addEventListener('click', () => {
    const open = navLinks.classList.toggle('open');
    burger.setAttribute('aria-expanded', String(open));
  });
  navLinks.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
    navLinks.classList.remove('open');
    burger.setAttribute('aria-expanded', 'false');
  }));

  /* ---------- Scroll progress bar ---------- */
  const progress = document.getElementById('scrollProgress');
  const updateProgress = () => {
    const h = document.documentElement;
    const scrolled = h.scrollTop;
    const height = h.scrollHeight - h.clientHeight;
    progress.style.width = height > 0 ? `${(scrolled / height) * 100}%` : '0%';
  };
  document.addEventListener('scroll', updateProgress, { passive: true });
  updateProgress();

  /* ---------- Back to top ---------- */
  const backToTop = document.getElementById('backToTop');
  document.addEventListener('scroll', () => {
    backToTop.classList.toggle('visible', window.scrollY > 600);
  }, { passive: true });
  backToTop.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));

  /* ---------- Animated counters ---------- */
  const counters = document.querySelectorAll('.stat-num');
  const animateCounter = (el) => {
    const target = parseFloat(el.dataset.count);
    const decimals = parseInt(el.dataset.decimal || '0', 10);
    const duration = 1400;
    const start = performance.now();
    const step = (now) => {
      const p = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(1 - p, 3);
      const val = target * eased;
      el.textContent = decimals ? val.toFixed(decimals) : Math.round(val).toLocaleString();
      if (p < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  };
  const counterObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        animateCounter(entry.target);
        counterObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.5 });
  counters.forEach(c => counterObserver.observe(c));

  /* ---------- Scroll reveal for cards ---------- */
  const revealables = document.querySelectorAll('.feature-card, .blog-card, .price-card');
  const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry, i) => {
      if (entry.isIntersecting) {
        setTimeout(() => entry.target.classList.add('in-view'), i * 60);
        revealObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15 });
  revealables.forEach(el => revealObserver.observe(el));

  /* ---------- Pricing monthly/yearly toggle ---------- */
  const billingSwitch = document.getElementById('billingSwitch');
  const amounts = document.querySelectorAll('.amount[data-monthly]');
  const labelMonthly = document.getElementById('labelMonthly');
  const labelYearly = document.getElementById('labelYearly');
  let yearly = false;
  const renderPricing = () => {
    amounts.forEach(a => {
      a.textContent = yearly ? a.dataset.yearly : a.dataset.monthly;
    });
    billingSwitch.setAttribute('aria-checked', String(yearly));
    labelMonthly.style.opacity = yearly ? '0.55' : '1';
    labelYearly.style.opacity = yearly ? '1' : '0.55';
    document.querySelectorAll('.period').forEach(p => p.textContent = '/mo');
  };
  billingSwitch.addEventListener('click', () => { yearly = !yearly; renderPricing(); });
  renderPricing();

  /* ---------- Comparison table expandable rows ---------- */
  document.querySelectorAll('.row-expand').forEach(btn => {
    btn.addEventListener('click', () => {
      const row = btn.closest('tr');
      const key = row.dataset.row;
      const detail = document.querySelector(`[data-row-detail="${key}"]`);
      const expanded = btn.getAttribute('aria-expanded') === 'true';
      btn.setAttribute('aria-expanded', String(!expanded));
      if (detail) detail.hidden = expanded;
    });
  });

  /* ---------- Testimonial carousel ---------- */
  const track = document.getElementById('carouselTrack');
  const slides = Array.from(track.children);
  const dotsWrap = document.getElementById('carouselDots');
  let current = 0;
  let autoTimer;

  slides.forEach((_, i) => {
    const dot = document.createElement('button');
    dot.setAttribute('aria-label', `Go to testimonial ${i + 1}`);
    if (i === 0) dot.classList.add('active');
    dot.addEventListener('click', () => goTo(i));
    dotsWrap.appendChild(dot);
  });
  const dots = Array.from(dotsWrap.children);

  function goTo(index) {
    current = (index + slides.length) % slides.length;
    track.style.transform = `translateX(-${current * 100}%)`;
    dots.forEach((d, i) => d.classList.toggle('active', i === current));
    restartAuto();
  }
  function restartAuto() {
    clearInterval(autoTimer);
    autoTimer = setInterval(() => goTo(current + 1), 6000);
  }
  document.getElementById('carouselPrev').addEventListener('click', () => goTo(current - 1));
  document.getElementById('carouselNext').addEventListener('click', () => goTo(current + 1));
  restartAuto();

  /* ---------- FAQ accordion ---------- */
  document.querySelectorAll('.accordion-trigger').forEach(trigger => {
    trigger.addEventListener('click', () => {
      const panel = trigger.nextElementSibling;
      const expanded = trigger.getAttribute('aria-expanded') === 'true';
      trigger.setAttribute('aria-expanded', String(!expanded));
      panel.style.maxHeight = expanded ? '0px' : `${panel.scrollHeight}px`;
    });
  });

  /* ---------- FAQ search ---------- */
  const faqSearch = document.getElementById('faqSearch');
  const faqItems = document.querySelectorAll('.accordion-item');
  const faqEmpty = document.getElementById('faqEmpty');
  faqSearch.addEventListener('input', () => {
    const q = faqSearch.value.trim().toLowerCase();
    let visibleCount = 0;
    faqItems.forEach(item => {
      const text = item.textContent.toLowerCase() + ' ' + (item.dataset.keywords || '');
      const match = !q || text.includes(q);
      item.style.display = match ? '' : 'none';
      if (match) visibleCount++;
    });
    faqEmpty.hidden = visibleCount !== 0;
  });

  /* ---------- Contact form validation ---------- */
  const form = document.getElementById('contactForm');
  const status = document.getElementById('formStatus');
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    let valid = true;
    form.querySelectorAll('.field').forEach(field => field.classList.remove('invalid'));

    const checks = [
      { id: 'fName', ok: form.fName.value.trim().length >= 2 },
      { id: 'fEmail', ok: /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.fEmail.value.trim()) },
      { id: 'fMessage', ok: form.fMessage.value.trim().length >= 10 },
    ];
    checks.forEach(({ id, ok }) => {
      if (!ok) {
        valid = false;
        document.getElementById(id).closest('.field').classList.add('invalid');
      }
    });

    if (!valid) {
      status.textContent = 'Please fix the highlighted fields.';
      status.style.color = '#ff6b6b';
      return;
    }
    status.style.color = '';
    status.textContent = 'Sending…';
    setTimeout(() => {
      status.textContent = `Thanks, ${form.fName.value.trim().split(' ')[0]} — we'll route this to the right team within one business day.`;
      form.reset();
    }, 900);
  });

  /* ---------- Sticky nav shadow ---------- */
  const nav = document.getElementById('siteNav');
  document.addEventListener('scroll', () => {
    nav.style.boxShadow = window.scrollY > 8 ? '0 8px 24px rgba(0,0,0,0.18)' : 'none';
  }, { passive: true });
})();
