# Fluxframe — Interactive SaaS Landing Page & Product Experience Platform

Submission for **Teyzix Core Internship (June Batch) — Task ID: FEWD-3**

A fictional product built for this task: **Fluxframe**, a visual API-workflow
automation tool for engineering teams ("wire your APIs, ship the pipeline").
The page and its copy are original work created for this assignment.

## What's inside

```
fluxframe/
├── index.html      # all page sections/markup
├── style.css       # design system, themes, responsive layout
├── script.js       # all interactivity (vanilla JS, no build step)
└── assets/         # (empty — page uses inline SVG/CSS instead of image files)
```

No framework or build tools are required — open `index.html` directly in a
browser, or serve the folder with any static server.

```bash
# optional local server
npx serve .
# or
python3 -m http.server 8080
```

## Sections implemented (per task spec)

- **Hero** — animated headline reveal, CTA buttons, animated stat counters,
  live SVG "pipeline" diagram with moving packets, blueprint grid background.
- **Product showcase** — feature grid with hover states, mock code/payload
  preview, connector chip gallery.
- **Pricing** — monthly/yearly toggle with animated price swap, "most wired"
  plan highlight.
- **Feature comparison** — table with expandable detail rows for RBAC and
  support/SLA.
- **Testimonials** — auto-advancing carousel with dot navigation, prev/next
  controls, star ratings.
- **FAQ** — accordion with smooth expand/collapse, live keyword search with
  empty-state message.
- **Blog preview** — featured article cards with categories.
- **Contact** — form with inline client-side validation (name, email format,
  message length) and success/error states, plus company info & social links.
- **Interactive extras** — dark/light mode toggle (persists for the session),
  sticky nav, scroll-progress bar, back-to-top button, scroll-triggered card
  reveal animations.
- **Responsive design** — fluid layout tested down to small mobile widths
  (nav collapses to a slide-down menu below 860px).

## Design notes

The visual direction leans into the product's own subject matter — workflow
orchestration — rather than a generic SaaS template:

- **Palette**: deep blueprint-navy (`#0D2438`) background with warm amber
  (`#FF8A3D`) as the single accent color, plus a small dose of cyan for the
  "second data packet" in the hero diagram. Light mode swaps to a warm paper
  tone while keeping the same accent.
- **Type**: JetBrains Mono for all headings/labels (nods to the developer
  audience and the "spec sheet" framing), Inter for body copy.
- **Signature element**: the animated hero pipeline diagram — three source
  nodes flowing into a transform node and out to three destinations, with
  small glowing "packets" travelling the dashed paths on loop. It's a direct,
  literal illustration of what the product does, not a decorative graphic.
- Section eyebrows are labelled like pipeline stages (`INPUT`, `TRANSFORM`,
  `VALIDATE`, `SINK`, `DEPLOY`...) since the page itself is structured like a
  pipeline running top to bottom.

## Accessibility

- Semantic landmarks (`header`, `main`, `footer`, `nav`, `section`).
- Visible keyboard focus states on all interactive elements.
- `aria-expanded` / `aria-checked` / `aria-pressed` used on toggles, the
  accordion, and the billing switch.
- `prefers-reduced-motion` respected — animations are disabled for users who
  request it.
- Color contrast checked against both dark and light themes.

## Tech stack

Plain HTML5, CSS3 (custom properties, CSS Grid/Flexbox, `color-mix()`), and
vanilla JavaScript — no frameworks, no build step, no external JS
dependencies. Google Fonts is the only external resource.

## Known limitations / next steps

- The contact form is front-end only (no backend endpoint) — it simulates a
  submit/success cycle client-side, per the "frontend-only" scope of the task.
- Screenshots of each major section should be captured from a running browser
  session and dropped into `assets/screenshots/` before final upload, since
  they need to be generated from an actual rendered page.
- A deployment link (Vercel/Netlify/GitHub Pages) can be added here once
  deployed, per the task's submission requirements.

---
*Built as part of the TEYZIX CORE Internship Program, Frontend Web
Development track (FEWD-3).*
